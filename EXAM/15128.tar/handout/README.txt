Missing features / faults: none.
As far as I've been able to interpret the exam, 
I've implemented everything, and the d2_test_client prints a tree matching the example in the associated header-file.
The d2 server output is identical with the expected output given on github (except for the PIDs of course).

faults in the precode, that have not been corrected by faculty:
-   In d2_lookup.h, it is specified that the function d2_send_request "Returns a value <= 0 in case of failure...".
    however, where the return code is checked in d_test_client.c:52 it is only checked if it is equal to 0 (if (ret ==0){}), 
    allowing the test program to continue running if the functions were implemented according to documentation. (this has been confirmed as a mistake by administrators).

-   A similar error exists in the test/documentation for d2_recv_response_size(); a number <= 0 should be returned, but this time only <0 is checked in the test program.


Implementation:
    D1:
        d1_create_client()
            allocates size for the peer. creates the socket and sets the seqno.
            all port- and adress-info is set id d1_get_peer_info().
        d1_delete()
            simply closes the socket, and frees the peer.
        d1_get_peer_info()
            uses the gethostbyname()-function to get a list of host-adresses. Uses teh first one as best fit.
            assigns the port and ip-adress to allow comunication.
        d1_recv_data()
            first allocates the space for the largest possible packet, as an array of bytes.
            reads into this buffer using the recv()-function.
            then, the packet is cast to a D1Header to allow for simple reading of flags, checksum and size.
            First the size is checked; the read-count of bytes recieved from recv() is compared to the size-field in the header. if they don't match, an ack with the opposite ackno of the incoming one is sent.
            then, the checksum is computed. The checksum-value in the header is stored in a temporary variable, then it is set to 0 in the header. this is because the checksum-computation needs them to be 0.
            The whole packet is now passed into the function that computes the checksum of an array of bytes. If the checksums don't match, a wrong ack is sent.
            After this point the incoming packet is assumed to be properly formed. The packet(from after the header) is copied into the buffer.
        d1_wait_ack()
            allocates a buffer for a header only. Sets a socket-option for the timeout on recieve, timeout occurs after one second.
            using the recv()-function to read into the buffer previously created, the function checks the return and what flags are set, to determite if the packet needs to be resent due to a timeout. 
            Next are checks to see if something is wrong with the packet flags. if it is not an ack something has failed, and the program returns. if the ACKNO is wrong, the function recursively calls d1_send_data(), which will call this again.
            On success the peers next seqno is flipped, and the function returns.
        d1_send_data()
            first, creates the header. sets the size and the appropriate flags(leaving the checksum for now).
            then, a larger packet-buffer is created; the header is copied to the start of it, then the incoming payload-buffer is put directly following the header. 
            this whole packet is passed into a simple checksum-function, and the checksum is placed back into the header-struct. The header is then re-copied into the packet at the same adress, overwriting the old one with an empty checksum.
            the packet-buffer is then sent using the sendto()-function, and the program waits for an ack.
        d1_send_ack()
            essentially does the reverse of d1_wait_ack(); creates a header, sets the ack-flag and the ackno-flag to be the same as the seqno-parameter.
            the size-field of the header will always be the size of a header, this is constant.
            Every field is of course flipped to network order before the entire header is passed to the checksum-function.
            A computed checksum is returned, and set (in network order) in the header. the header is sent using the  sendto()-function.
        d1_compute_checksum()  -  my own function
            a simple helper-function to compute the checksum of a buffer, according to the ChecksumExplanation.md.
            This function does not care where the checksum-field is within the buffer, as long as it is 0.
            It takes two parameters: a pointer to the start of the buffer to checksum(*packet), and the size of the buffer (sz).
            The function simply loops over the packet, and xors every even byte and every odd byte separately(bytes are 1-indexed in the .md-file, so i use the same terminology here.)
            odd byte xor is shifted 8 bits left, and padded with the even-xor for the last 8 bits, and returned as the required uint16_t(in host byte order).

    D2:
        d2_client_create()
            creates an empty D2Client, and uses the d2_create_client() to fill the clients peer.
            the D2Client is not modified from the precode, it only contains the D1Peer.
        d2_clientt_delete()
            calls d1_delete(). Frees the D2Client.
        d2_send_request()
            checks the incoming id is >1000.
            Creates a request-packet, and sets the type to TYPE_REQUEST and id to the id-parameter (both in network byte order, of course).
            copies the structure to a byte-buffer to allow it to be interpreted as bytes, this is the same way i implemented the send in d1.
        d2_recv_response_size()
            uses recv() to read into the buffer first. Casts the buffer to a PacketHeader first, to check that the type is TYPE_RESPONSE_SIZE.
            If it is, casts the buffer to a PacketresponseSize, converts the size-variable to host order and returns it.
        d2_recv_response()
            same as d2_recv_response_size(), reads into the buffer, casts to PacketHeader and checks type.
            if type is correct, simply returns the read-count from the d1_recv_data()-function, aka the bytes read.
        d2_alloc_local_tree()
            I've chosen to implement the tree as an array, mainly for the simplicity and the idea that the nodes are assigned ids and added to the tree in order of a DFS, meaning the id of a node is the same as its index.
            This means localTreeStore only holds the number of nodes (size of the array), and a pointer to the first one in the array.
            Then, enough space is allocated to allow all these nodes to be stored.
        d2_free_local_tree()
            Frees the space allocated for the nodes, and the tree-struct with the number of nodes.
        d2_add_to_local_tree()
            finds the number of minimum nodes in the buffer (By minimum node i mean a node with no children, this only has the size of 3*(sizeof(uint32_t)).).
            of course, this number could be more than 5. but documentation says no more than 5 nodes appear in each buffer. 
            This number essentially just allows for reading packets with less than 5 nodes - aka last responses.
            The size of each node in the buffer is variable - depending on the number of children it has. This means each node cannot simply be cast, but must be dynamically read.
            for each node:
                first, the ID, value, and num_children are read: these have to be present, and are always the same size and first in the structure.
                for each read the buffer is advanced, so the pointer is where the next value should be read from.
                then, for num_children-iterations, the next sizeof(uint32_t) bytes are read as the child_ids. for each read, the buffer is advanced. 
                finally, the node is added to the array at the given node_idx, and node_idx is advanced by 1. 
            finally, after every node in the buffer was added, the node_idx is returned. this points to where the next node should be added from the next buffer.
        print_node()  -  my own function
            this is a recursive function to print a single node. it calls itself for each child. This was the simplest way to keep track of the "depth" of each node, as it is just the height of the call stack from the first call.
            the tree-parameter is the whole tree, the node_id is the id, or index, for the node to print. the level is the height of the call stack, or, how many dashes to print to represent depth.
        d2_print_tree()
            starts the recursive function to print each node. simply calls the recursive function with id 0 for the first node, and depth 0.